# ALIGN Note Organizer
## Open Source Developer Briefing

---

## What This Is

A web application that takes raw student notes and restructures them into the 12-stage ALIGN Neurocognitive Learning Pathway — personalized to the student's subject, grade level, learning style, and personal interests.

Built on the UCAN framework by Paul R. Travis III / The Human Sanity Project.

---

## How It Works

1. Student completes a 5-question profile (one time)
2. Student pastes raw class notes
3. Claude API restructures the notes into all 12 ALIGN stages
4. Output is saved and retrievable

The personalization layer uses the student's stated personal interest to create concrete connections at Stage 1 (sensory attention) and Stage 6 (emotional valuation) — the two stages most responsible for whether information consolidates into long-term memory.

---

## Files

```
align_notes/
├── backend.py     FastAPI server — profile management, Claude API integration
├── index.html     Complete frontend — single file, no build step required
└── README.md
```

---

## Setup

**Backend:**
```bash
pip install fastapi uvicorn anthropic sqlalchemy pydantic

export ANTHROPIC_API_KEY=your_key_here

python backend.py
# Runs on http://localhost:8001
```

**Frontend:**
```bash
# Just open index.html in a browser
# Or serve with any static file server
python -m http.server 3000
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /onboarding | Create user profile from survey |
| POST | /notes/process | Submit raw notes — returns ALIGN-structured output |
| GET | /notes/{user_id} | List all saved notes for user |
| GET | /notes/detail/{note_id} | Get full structured note |

---

## Monetization Path

**Free tier:** Basic note restructuring, 5 notes/month

**Student subscription ($4.99/month):**
- Unlimited notes
- All subjects personalized
- Progress tracking
- Spaced repetition reminders

**Institutional license ($X/student/year):**
- District or school-wide deployment
- Teacher dashboard
- Usage analytics
- LMS integration (Canvas, Google Classroom)

---

## What Needs Building

1. User authentication (currently no passwords — add Auth0 or similar)
2. Spaced repetition reminder system
3. Mobile app wrapper (Capacitor or React Native WebView)
4. Teacher/admin dashboard for institutional tier
5. LMS integration plugins

---

## License

MIT. Use freely. Attribution appreciated.

Framework: Creative Commons CC-BY 4.0
Paul R. Travis III / The Human Sanity Project
humansanityproject@gmail.com
