"""
ALIGN Note Organizer — Backend
FastAPI server with Anthropic API integration.
Restructures raw student notes into the 12-stage ALIGN sequence.

Dependencies:
    pip install fastapi uvicorn anthropic sqlalchemy pydantic
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional, List
import anthropic
import json
import uuid
import sqlite3
from datetime import datetime
from pathlib import Path

app = FastAPI(title="ALIGN Note Organizer", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from environment

# ─── DATABASE ────────────────────────────────────────────────

DB_PATH = "align_notes.db"

def init_db():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            created_at TEXT,
            subject TEXT,
            grade_level TEXT,
            learning_style TEXT,
            note_habit TEXT,
            personal_interest TEXT
        );
        CREATE TABLE IF NOT EXISTS notes (
            id TEXT PRIMARY KEY,
            user_id TEXT,
            raw_input TEXT,
            structured_output TEXT,
            subject TEXT,
            created_at TEXT
        );
    """)
    con.commit()
    con.close()

init_db()

def db():
    return sqlite3.connect(DB_PATH)


# ─── MODELS ──────────────────────────────────────────────────

class SurveyResponse(BaseModel):
    subject: str
    grade_level: str
    learning_style: str       # examples | stories | diagrams | definitions
    note_habit: str           # review_before_tests | never_look_again | daily_review
    personal_interest: str    # free text — what they genuinely care about

class NoteInput(BaseModel):
    user_id: str
    raw_notes: str
    subject: Optional[str] = None

class NoteResponse(BaseModel):
    note_id: str
    structured: dict
    raw_input: str


# ─── ONBOARDING ──────────────────────────────────────────────

@app.post("/onboarding")
async def create_profile(survey: SurveyResponse):
    user_id = str(uuid.uuid4())
    con = db()
    con.execute(
        "INSERT INTO users VALUES (?,?,?,?,?,?,?)",
        (user_id, datetime.utcnow().isoformat(),
         survey.subject, survey.grade_level,
         survey.learning_style, survey.note_habit,
         survey.personal_interest)
    )
    con.commit()
    con.close()
    return {"user_id": user_id, "status": "profile_created"}


def get_profile(user_id: str) -> Optional[dict]:
    con = db()
    row = con.execute(
        "SELECT * FROM users WHERE id=?", (user_id,)
    ).fetchone()
    con.close()
    if not row:
        return None
    return {
        "id": row[0], "created_at": row[1],
        "subject": row[2], "grade_level": row[3],
        "learning_style": row[4], "note_habit": row[5],
        "personal_interest": row[6]
    }


# ─── ALIGN PROMPT ENGINE ─────────────────────────────────────

def build_align_prompt(raw_notes: str, profile: dict, subject: str) -> str:
    style_map = {
        "examples":    "concrete examples and real-world scenarios",
        "stories":     "narrative and story-based framing",
        "diagrams":    "structured visual breakdowns and clear categories",
        "definitions": "precise definitions and logical sequence"
    }
    habit_map = {
        "review_before_tests": "The student reviews notes before exams — make the output scannable with clear stage labels.",
        "never_look_again":    "The student rarely revisits notes — make each stage memorable and self-contained.",
        "daily_review":        "The student reviews daily — make the output build progressively across stages."
    }

    learning_style = style_map.get(profile["learning_style"], "clear explanations")
    note_habit = habit_map.get(profile["note_habit"], "")
    interest = profile["personal_interest"]
    grade = profile["grade_level"]

    return f"""You are an educational framework assistant applying the ALIGN Neurocognitive Learning Pathway.

STUDENT PROFILE:
- Subject: {subject}
- Grade level: {grade}
- Learns best through: {learning_style}
- Personal interest outside school: {interest}
- Note habit: {note_habit}

RAW NOTES TO RESTRUCTURE:
{raw_notes}

TASK:
Restructure these notes into the 12-stage ALIGN sequence. Each stage must be concise — 2 to 4 sentences maximum. Use the student's personal interest ({interest}) to create a concrete connection at Stage 1 and Stage 6. Match the learning style ({learning_style}) throughout.

Return ONLY a valid JSON object with this exact structure:
{{
  "subject": "{subject}",
  "core_concept": "one sentence naming what these notes are about",
  "stages": {{
    "1": {{
      "name": "Sensory Attention",
      "content": "A concrete story, image, or scenario connecting {interest} to this concept. No abstract definitions yet."
    }},
    "2": {{
      "name": "Perceptual Filtering",
      "content": "Why does this matter to someone at {grade} level? Make the relevance explicit and personal."
    }},
    "3": {{
      "name": "Language Comprehension",
      "content": "Define the core concept clearly, connected to what was established in Stage 1."
    }},
    "4": {{
      "name": "Conflict Detection",
      "content": "Name the contradiction, problem, or surprising fact in these notes. What does not fit what you already thought?"
    }},
    "5": {{
      "name": "Cognitive Reappraisal",
      "content": "The key evidence or reasoning from the notes. What does the evidence actually show?"
    }},
    "6": {{
      "name": "Emotional Valuation",
      "content": "Connect this material to {interest} or to something the student genuinely cares about. One concrete bridge."
    }},
    "7": {{
      "name": "Motivation",
      "content": "What becomes possible now that you understand this? What door does this open?"
    }},
    "8": {{
      "name": "Memory Reconsolidation",
      "content": "What does this update or change in how you understood this topic before?"
    }},
    "9": {{
      "name": "Metacognition",
      "content": "What part of these notes is clearest? What is still fuzzy? Name both honestly."
    }},
    "10": {{
      "name": "Identity Integration",
      "content": "Complete this: I am someone who now understands that... [complete from the notes]"
    }},
    "11": {{
      "name": "Behavioral Application",
      "content": "One specific, concrete thing to do with this knowledge this week. Not vague — exact."
    }},
    "12": {{
      "name": "Collective Transmission",
      "content": "Explain the core concept in one sentence you could say to a friend who was not in class."
    }}
  }},
  "quick_review": "Three bullet points — the three things most likely to appear on a test, stated plainly."
}}

Return only the JSON. No preamble. No explanation. No markdown fences."""


# ─── NOTE PROCESSING ─────────────────────────────────────────

@app.post("/notes/process", response_model=NoteResponse)
async def process_notes(note: NoteInput):
    profile = get_profile(note.user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="User profile not found. Complete onboarding first.")

    subject = note.subject or profile["subject"]
    prompt = build_align_prompt(note.raw_notes, profile, subject)

    # Call Claude
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}]
    )

    raw_response = message.content[0].text.strip()

    # Parse JSON response
    try:
        structured = json.loads(raw_response)
    except json.JSONDecodeError:
        # Strip any accidental markdown fences
        cleaned = raw_response.replace("```json", "").replace("```", "").strip()
        structured = json.loads(cleaned)

    # Save to database
    note_id = str(uuid.uuid4())
    con = db()
    con.execute(
        "INSERT INTO notes VALUES (?,?,?,?,?,?)",
        (note_id, note.user_id, note.raw_notes,
         json.dumps(structured), subject,
         datetime.utcnow().isoformat())
    )
    con.commit()
    con.close()

    return NoteResponse(
        note_id=note_id,
        structured=structured,
        raw_input=note.raw_notes
    )


@app.get("/notes/{user_id}")
async def get_user_notes(user_id: str):
    con = db()
    rows = con.execute(
        "SELECT id, subject, created_at, raw_input FROM notes WHERE user_id=? ORDER BY created_at DESC",
        (user_id,)
    ).fetchall()
    con.close()
    return [{"id": r[0], "subject": r[1], "created_at": r[2], "preview": r[3][:100]} for r in rows]


@app.get("/notes/detail/{note_id}")
async def get_note(note_id: str):
    con = db()
    row = con.execute(
        "SELECT * FROM notes WHERE id=?", (note_id,)
    ).fetchone()
    con.close()
    if not row:
        raise HTTPException(status_code=404, detail="Note not found")
    return {
        "id": row[0], "user_id": row[1],
        "raw_input": row[2],
        "structured": json.loads(row[3]),
        "subject": row[4], "created_at": row[5]
    }


@app.get("/health")
async def health():
    return {"status": "operational"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=True)
